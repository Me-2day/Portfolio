from django.contrib import admin
from .models import Author, Post


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("title", "color", "pinned", "updated_at")
    list_filter = ("color", "pinned")
    search_fields = ("title", "content")


admin.site.register(Author)
