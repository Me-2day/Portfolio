from django.shortcuts import render, get_object_or_404, redirect
from .models import Post
from .forms import PostForm

def post_list(request):
    """
    View to display a list of all sticky notes.

    :param request: The HTTP request object.
    :return: A rendered template with the list of notes.
    """
    posts = Post.objects.all()
    context = {
        "posts": posts,
        "page_title": "Sticky Notes",
    }

    return render(request, "posts/post_list.html", context)


def post_detail(request, pk):
    """
    View to display the details of a single sticky note.

    :param request: The HTTP request object.
    :param pk: The primary key of the note to be displayed.
    :return: A rendered template with the note details.
    """
    post = get_object_or_404(Post, pk=pk)
    return render(request, "posts/post_detail.html", {"post": post})


def post_create(request):
    """
    View to create a new sticky note.

    :param request: The HTTP request object.
    :return: Rendered template for creating a new note.
    """
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.save()
            return redirect("post_list")
    else:
        form = PostForm()
    return render(
        request,
        "posts/post_form.html",
        {"form": form, "form_title": "New note"},
    )


def post_update(request, pk): 
    """ 
    View to update an existing sticky note.
    
    :param request: HTTP request object. 
    :param pk: Primary key of the note to be updated.
    :return: Rendered template for updating the specified note.
    """ 
    
    post = get_object_or_404(Post, pk=pk) 
    if request.method == "POST": 
        form = PostForm(request.POST, instance=post) 
        if form.is_valid(): 
            post = form.save(commit=False) 
            post.save() 
            return redirect("post_list") 
    else: 
        form = PostForm(instance=post) 
    return render(
        request,
        "posts/post_form.html",
        {"form": form, "form_title": "Edit note"},
    )


def post_delete(request, pk):
    """
    View to delete an existing sticky note.
    
    :param request: HTTP request object. 
    :param pk: Primary key of the note to be deleted.
    :return: Redirect to the note list after deletion.
    """
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        post.delete()
        return redirect("post_list")
    return render(request, "posts/post_confirm_delete.html", {"post": post})
