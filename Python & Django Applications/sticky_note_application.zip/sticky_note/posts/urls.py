from django.urls import path
from .views import (
    post_list,
    post_detail,
    post_create,
    post_update,
    post_delete
)

urlpatterns = [
    path("", post_list, name="post_list"),
    path("notes/new/", post_create, name="post_create"),
    path("notes/<int:pk>/", post_detail, name="post_detail"),
    path("notes/<int:pk>/edit/", post_update, name="post_update"),
    path("notes/<int:pk>/delete/", post_delete, name="post_delete"),
]
