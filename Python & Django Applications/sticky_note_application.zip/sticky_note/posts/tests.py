from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Author, Post


class StickyNoteUseCaseTests(TestCase):
    def test_user_can_create_new_sticky_note(self):
        response = self.client.post(
            reverse("post_create"),
            {
                "title": "Shopping list",
                "content": "Milk, bread, and coffee",
                "color": Post.YELLOW,
                "pinned": "on",
            },
        )

        self.assertRedirects(response, reverse("post_list"))
        post = Post.objects.get(title="Shopping list")
        self.assertEqual(post.content, "Milk, bread, and coffee")
        self.assertEqual(post.color, Post.YELLOW)
        self.assertTrue(post.pinned)

    def test_user_can_edit_existing_sticky_note(self):
        post = Post.objects.create(
            title="Old title",
            content="Old content",
            color=Post.YELLOW,
        )

        response = self.client.post(
            reverse("post_update", args=[post.pk]),
            {
                "title": "Updated title",
                "content": "Updated content",
                "color": Post.BLUE,
                "pinned": "on",
            },
        )

        self.assertRedirects(response, reverse("post_list"))
        post.refresh_from_db()
        self.assertEqual(post.title, "Updated title")
        self.assertEqual(post.content, "Updated content")
        self.assertEqual(post.color, Post.BLUE)
        self.assertTrue(post.pinned)

    def test_user_can_delete_existing_sticky_note(self):
        post = Post.objects.create(
            title="Delete me",
            content="This note should be deleted",
            color=Post.PINK,
        )

        response = self.client.post(reverse("post_delete", args=[post.pk]))

        self.assertRedirects(response, reverse("post_list"))
        self.assertFalse(Post.objects.filter(pk=post.pk).exists())

    def test_admin_can_manage_authors(self):
        User = get_user_model()
        admin_user = User.objects.create_superuser(
            username="admin",
            email="admin@example.com",
            password="password123",
        )
        self.client.force_login(admin_user)

        response = self.client.post(
            reverse("admin:posts_author_add"),
            {
                "name": "Chris",
                "_save": "Save",
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(Author.objects.filter(name="Chris").exists())
