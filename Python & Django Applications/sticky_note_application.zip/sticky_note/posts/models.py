from django.db import models

class Post(models.Model):
    """Model representing a sticky note.

    Fields:
    - title: CharField for the note title.
    - content: TextField for the note content.
    - color: CharField for the sticky note color.
    - pinned: BooleanField for whether the note should be highlighted first.
    - created_at: DateTimeField for when the note was created.
    - updated_at: DateTimeField for when the note was last updated.

    Relationships:
    - author: ForeignKey representing the author of the note.

    Methods:
    - __str__: Returns the title of the note as its string representation.

    :param models.Model: The base class for all Django models.
    """

    YELLOW = "yellow"
    BLUE = "blue"
    GREEN = "green"
    PINK = "pink"

    COLOR_CHOICES = [
        (YELLOW, "Yellow"),
        (BLUE, "Blue"),
        (GREEN, "Green"),
        (PINK, "Pink"),
    ]

    title = models.CharField(max_length=225)
    content = models.TextField()
    color = models.CharField(max_length=20, choices=COLOR_CHOICES, default=YELLOW)
    pinned = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    author = models.ForeignKey(
        "Author", on_delete=models.CASCADE, null=True, blank=True
    )

    class Meta:
        ordering = ["-pinned", "-updated_at", "-created_at"]

    def __str__(self):
        return self.title


class Author(models.Model):
    """Model representing an author of a note.

    Fields:
    - name: CharField for the author's name.

    Methods:
    - __str__: Returns the name of the author as its string representation.

    :param models.Model: The base class for all Django models.
    """

    name = models.CharField(max_length=225)

    def __str__(self):
        return self.name
