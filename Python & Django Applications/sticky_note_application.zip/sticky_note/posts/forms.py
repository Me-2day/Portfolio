from django import forms
from .models import Post


class PostForm(forms.ModelForm):
    """
    Form for creating and updating sticky notes.

    Fields: 
    - title: CharField for the note title.
    - content: TextField for the note content.
    - color: ChoiceField for the note color.
    - pinned: BooleanField for pinning the note.

    Meta class:
    - Defines the model to use (Post) and the fields to include in the form.

    :param forms.ModelForm: Django's ModelForm class.
    """

    class Meta:
        model = Post
        fields = ["title", "content", "color", "pinned"]
        labels = {
            "title": "Note title",
            "content": "Note",
            "color": "Color",
            "pinned": "Pin this note",
        }
        widgets = {
            "content": forms.Textarea(attrs={"rows": 6}),
        }
